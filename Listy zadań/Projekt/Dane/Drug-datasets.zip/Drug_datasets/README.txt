The Drug_datasets.zip folder contains 41 drug design datasets in arff format. 
The datasets with 1143 features are formed using Adriana.Code software  (www.molecular-networks.com/software/adrianacode).
The molecules and outputs are taken from the original studies. 
The other dataset are taken exactly from the original studies.
The datasets' referances are in the Drug_dataset_referances.xls file.
The last attribute in each file is the target.
